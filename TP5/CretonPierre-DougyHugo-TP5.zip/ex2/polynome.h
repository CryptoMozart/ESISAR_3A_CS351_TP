#include <stdio.h>
#include <stdlib.h>

#define NBMAX 100
typedef struct {
	float coeff;
	int degre;
}Terme;
typedef Terme Polynome[NBMAX];

void addPolynomes(Polynome p1, Polynome p2, Polynome res);
