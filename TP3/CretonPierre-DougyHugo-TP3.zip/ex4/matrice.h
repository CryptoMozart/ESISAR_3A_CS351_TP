#include <stdio.h>

#define X 100

void creerAfficherMatrice();
void afficherMatrice(int matrice[X][X],int ligne,int colonne);
void additionnerMatrice(int matrice1[X][X], int matrice2[X][X], int ligne, int colonne);
void transposee(int matrice[X][X], int ligne, int colonne);
void produitMatrice(int matrice1[X][X], int ligne1, int colonne1, int matrice[X][X],int colonne2);
