#include <stdio.h>

void dessineCarre(int x,int y,int taille);
void dessineCarreDiagonale(int x, int y, int taille);
void dessineMosaique(int x,int y,int taille,int hauteur, int largeur);
void dessineMosaiqueAvecSouris(int taille,int hauteur, int largeur );
