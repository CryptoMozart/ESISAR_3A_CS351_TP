#include <stdio.h>

void JeuMultiPoints();
void JeuMulti();
