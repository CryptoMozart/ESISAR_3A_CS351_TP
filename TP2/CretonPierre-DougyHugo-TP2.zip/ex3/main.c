#include <stdio.h>
#include "mathematiques.h"

int main(){
	/*printf("%d\n",quotient(10,0));
	printf("%d\n",reste(12,0));
	printf("%d\n",valeurAbsolue(0));
	printf("%d\n",ppcm(0,34)); 
	printf("%d\n",puissanceMB(2,18));
	printf("%d\n",sommeDeslmpairs(1,15));
	printf("%d\n",estUneDecompositionDe(7,13)); */
	testBibliotheque();
			}
