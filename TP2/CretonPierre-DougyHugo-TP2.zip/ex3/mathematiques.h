#include <stdio.h>

int quotient(unsigned int a,unsigned int b);
int reste(unsigned int a, unsigned int b);
int valeurAbsolue(int a);
int pgcd(int a,int b);
int ppcm(int a,int b);
int puissanceMB(int x,int n);
int sommeDeslmpairs(int d,int f);
int estUneDecompositionDe(int d, int f);
void testBibliotheque();
