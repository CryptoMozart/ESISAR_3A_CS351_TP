#include <stdio.h>
#include "graphlib.h"

void initalise_carre(int x ,int y ,int taille);
void afficher_fractale(int n);
void fractale(int rang,int n,int x,int y,int taille);
void dessine_carre(int x,int y, int taille);
