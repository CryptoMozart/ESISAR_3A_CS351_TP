#include <stdio.h>

void hanoi(int n,char A,char B, char C);
/*void affichage(int n);*/