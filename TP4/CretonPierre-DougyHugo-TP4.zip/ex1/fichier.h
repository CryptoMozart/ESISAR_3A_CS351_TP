#include <stdio.h>

int lireDonnees(char nomFichier[], int T[]);
void afficherTableau(int T[],int nb);
int estTrie(int T[],int nb);
int triABulles(int T[], int nb);
void enregistrerDonnees(char nomFichier[],int T[],int nb);
