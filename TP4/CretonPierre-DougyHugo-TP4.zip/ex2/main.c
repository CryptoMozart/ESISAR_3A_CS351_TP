#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "chaine.h"

#define X 100

int main(){
	char chaine[]="cauchyxz";
	char chaine2[]="cauchyx";
	//char chaineVide[X]="";
	//int taille = myStrlen(chaine);
	//char dest[X];
	//printf("%d\n",taille);
	//printf("%s",myStrcpy(dest,chaine,taille));
	//afficheEnHexadecimal(chaine,taill);
	//afficheEnDecimal(chaine,taille);
	//printf("%s\n",mettreEnMajuscule(chaine));
	//free(mot);
	//printf("%s\n",mettreEnMinuscule(chaine));
	//free(mot);
	//printf("%s\n",transformerMinMaj(chaine));
	//printf("%s\n",retournerMot(chaine));
	//printf("%d\n",rechercherCaractereG(chaine,'i'));
	//printf("%d\n",rechercherCaractereD(chaine,'i'));
	//printf("%d",estPalindrome(chaine,0,5));
	printf("%d",comparerChaine(chaine,chaine2));
	//printf("%d",valeurDecimale(chaine));
	//int n = 2546;
	//intVersChaine(n,chaineVide);
	//printf("%s",chaineVide);	
	return 0;
}
